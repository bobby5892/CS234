﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMaintenance
{
    public static class MMABooksEntity
    {
        public static MMABooksEntities mmaBooks = new MMABooksEntities();
    }
}
