﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;


namespace Lab6PropsClasses
{
   [TestFixture]
   public class ProductPropsTest
    {
        [Test]
        public void TestGetState()
        {
            ProductProps p = new ProductProps();

        }
    }
}
